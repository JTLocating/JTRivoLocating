function fitSiteForgePageToViewport() {
  const stage = document.querySelector(".sf-stage");
  const page = document.querySelector(".sf-page");
  if (!stage || !page) { return; }
  page.style.transform = "scale(1)";
  const pageWidth = Math.max(1, page.offsetWidth);
  const pageHeight = Math.max(1, page.offsetHeight);
  const viewportWidth = Math.max(1, document.documentElement.clientWidth);
  const viewportHeight = Math.max(1, window.innerHeight || document.documentElement.clientHeight);
  const scale = Math.min(1, viewportWidth / pageWidth);
  page.style.transform = "scale(" + scale + ")";
  const fittedHeight = Math.ceil(pageHeight * scale);
  const stageHeight = Math.max(viewportHeight, fittedHeight);
  stage.style.height = stageHeight + "px";
  stage.style.minHeight = stageHeight + "px";
  const footer = page.querySelector(".sf-footer");
  if (footer) {
    const footerBackground = window.getComputedStyle(footer).backgroundColor;
    if (footerBackground && footerBackground !== "rgba(0, 0, 0, 0)" && footerBackground !== "transparent") {
      document.body.style.background = footerBackground;
      stage.style.background = footerBackground;
    }
  }
}

window.addEventListener("load", fitSiteForgePageToViewport);
window.addEventListener("resize", fitSiteForgePageToViewport);
requestAnimationFrame(fitSiteForgePageToViewport);

document.addEventListener("click", function(event) {
  const button = event.target.closest(".sf-nav-menu-button");
  const clickedNav = button ? button.closest('.sf-navigation') : null;
  document.querySelectorAll('.sf-navigation.is-open').forEach(function(nav) {
    if (!clickedNav || nav !== clickedNav) {
      nav.classList.remove("is-open");
      const openButton = nav.querySelector(".sf-nav-menu-button");
      if (openButton) { openButton.setAttribute("aria-expanded", "false"); }
    }
  });
  const navLink = event.target.closest(".sf-nav-links a");
  if (navLink) {
    document.querySelectorAll(".sf-navigation.is-open").forEach(function(nav) {
      nav.classList.remove("is-open");
      const openButton = nav.querySelector(".sf-nav-menu-button");
      if (openButton) {
        openButton.setAttribute("aria-expanded", "false");
        openButton.setAttribute("aria-label", "Open navigation menu");
      }
    });
    document.documentElement.classList.remove("sf-nav-open");
    return;
  }
  if (!button || !clickedNav) {
    document.documentElement.classList.toggle("sf-nav-open", document.querySelector(".sf-navigation.is-open") !== null);
    return;
  }
  event.preventDefault();
  const nextOpen = !clickedNav.classList.contains("is-open");
  clickedNav.classList.toggle("is-open", nextOpen);
  document.documentElement.classList.toggle("sf-nav-open", nextOpen);
  button.setAttribute("aria-expanded", nextOpen ? "true" : "false");
  button.setAttribute("aria-label", nextOpen ? "Close navigation menu" : "Open navigation menu");
});

document.addEventListener("submit", function(event) {
  const form = event.target;
  if (!form.matches(".sf-form")) { return; }
  const action = (form.getAttribute("action") || "").trim();
  const status = form.querySelector(".sf-form-status");
  if (!action || action === "#" || form.dataset.siteforgeDestination === "not-connected") {
    event.preventDefault();
    if (status) {
      status.dataset.state = "warning";
      status.textContent = "This demo contact form is not connected. No information was sent. Add a Zoho endpoint in SiteForge Settings to receive submissions.";
    } else {
      alert("This demo contact form is not connected. No information was sent.");
    }
    return;
  }
  if (status) {
    status.dataset.state = "sending";
    status.textContent = "Sending contact information to the configured form endpoint...";
  }
});

document.querySelectorAll(".sf-flip-card").forEach(function(card) {
  card.addEventListener("click", function(event) {
    event.preventDefault();
    const flipped = !card.classList.contains("is-flipped");
    card.classList.toggle("is-flipped", flipped);
    card.setAttribute("aria-pressed", flipped ? "true" : "false");
  });
  if (card.dataset.liquidHover !== "true") { return; }
  card.addEventListener("pointermove", function(event) {
    const rect = card.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / Math.max(1, rect.width)) - 0.5;
    const y = ((event.clientY - rect.top) / Math.max(1, rect.height)) - 0.5;
    card.style.setProperty("--sf-tilt-x", (-y * 7).toFixed(2) + "deg");
    card.style.setProperty("--sf-tilt-y", (x * 8).toFixed(2) + "deg");
    card.style.setProperty("--sf-glow-x", ((x + 0.5) * 100).toFixed(1) + "%");
    card.style.setProperty("--sf-glow-y", ((y + 0.5) * 100).toFixed(1) + "%");
  });
  card.addEventListener("pointerleave", function() {
    card.style.setProperty("--sf-tilt-x", "0deg");
    card.style.setProperty("--sf-tilt-y", "0deg");
  });
});

if (window.__SITEFORGE_LIVE__) {
  let liveVersion = window.__SITEFORGE_LIVE_VERSION__ || "";
  async function checkSiteForgeLiveVersion() {
    const activeTag = document.activeElement ? document.activeElement.tagName : "";
    if (["INPUT", "TEXTAREA", "SELECT"].includes(activeTag)) { return; }
    try {
      const response = await fetch("assets/siteforge-live.json?cache=" + Date.now(), { cache: "no-store" });
      if (!response.ok) { return; }
      const marker = await response.json();
      if (marker.version && liveVersion && marker.version !== liveVersion) {
        window.location.reload();
      }
    } catch (_) {
      // File previews can block fetch in some browsers. In that case Live View stays stable instead of looping.
    }
  }
  setInterval(checkSiteForgeLiveVersion, 1600);
}